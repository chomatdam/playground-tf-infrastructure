In order for us to consider merging a contribution, you will need to sign our
**C**ontributor **L**icense **A**greement.

> The purpose of a CLA is to ensure that the guardian of a project's outputs has the necessary ownership or grants of rights over all contributions to allow them to distribute under the chosen licence.
> [Wikipedia](http://en.wikipedia.org/wiki/Contributor_License_Agreement)

You can read and sign our full Contributor License Agreement [here](http://clabot.confluent.io/cla).
